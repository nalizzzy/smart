package com.sun.jersey.api.client;

public enum ClientResponse {

}
