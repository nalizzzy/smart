
public class ClientResponse {

}
