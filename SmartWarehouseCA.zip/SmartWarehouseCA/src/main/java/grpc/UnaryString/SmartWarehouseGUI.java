package grpc.UnaryString;

import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class SmartWarehouseGUI {

	private JFrame frame;
	private JTextField textNumber1;
	private JTextField textNumber2;
	private JTextArea textResponse;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SmartWarehouseGUI window = new SmartWarehouseGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Initialize the contents of the frame.
	 */
	public SmartWarehouseGUI() {
		frame = new JFrame();
		frame.setTitle("Radio-Frequency identifer");
		frame.setBounds(100, 100, 500, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		BoxLayout bl = new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS);

		frame.getContentPane().setLayout(bl);

		JPanel panel_service_1 = new JPanel();
		frame.getContentPane().add(panel_service_1);
		panel_service_1.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));

		JLabel lblNewLabel_1 = new JLabel("product tracker");
		panel_service_1.add(lblNewLabel_1);

		textNumber1 = new JTextField();
		panel_service_1.add(textNumber1);
		textNumber1.setColumns(10);

		JLabel lblNewLabel_2 = new JLabel("Scanner");
		panel_service_1.add(lblNewLabel_2);

		textNumber2 = new JTextField();
		panel_service_1.add(textNumber2);
		textNumber2.setColumns(10);

		final JComboBox comboOperation = new JComboBox();
		comboOperation.setModel(new DefaultComboBoxModel(new String[] { "Location", "status", "Availability" }));
		panel_service_1.add(comboOperation);

		JButton btnCalculate = new JButton("");
		btnCalculate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int num1 = Integer.parseInt(textNumber1.getText());
				int num2 = Integer.parseInt(textNumber2.getText());

				int index = comboOperation.getSelectedIndex();

				if (index == 0) {
					textResponse.append("Location" + String.valueOf(num1 + num2));
				}
				if (index == 1) {
					textResponse.append("status" + String.valueOf(num1 - num2));
				}
				if (index == 2) {
					textResponse.append("availiablity" + String.valueOf(num1 * num2));
				}

			}
		});
		panel_service_1.add(btnCalculate);

		textResponse = new JTextArea(3, 20);
		textResponse.setLineWrap(true);
		textResponse.setWrapStyleWord(true);

		JScrollPane scrollPane = new JScrollPane(textResponse);

		// textResponse.setSize(new Dimension(15, 30));
		panel_service_1.add(scrollPane);

		JPanel panel_service_2 = new JPanel();
		frame.getContentPane().add(panel_service_2);

		JPanel panel_service_3 = new JPanel();
		frame.getContentPane().add(panel_service_3);

	}

}
