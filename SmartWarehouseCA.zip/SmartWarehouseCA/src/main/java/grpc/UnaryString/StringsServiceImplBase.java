package grpc.UnaryString;

public class StringsServiceImplBase {

}
