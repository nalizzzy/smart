package grpc.UnaryString;

public interface CheckFullStock<T> {

}
