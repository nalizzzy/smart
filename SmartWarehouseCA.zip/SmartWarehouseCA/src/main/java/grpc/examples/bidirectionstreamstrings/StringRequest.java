package grpc.examples.bidirectionstreamstrings;

import com.google.protobuf.Message;

public class StringRequest {

	public static Message getDefaultInstance() {
		// TODO Auto-generated method stub
		return null;
	}

	public static Message getDefaultInstance() {
		// TODO Auto-generated method stub
		return null;
	}

}
